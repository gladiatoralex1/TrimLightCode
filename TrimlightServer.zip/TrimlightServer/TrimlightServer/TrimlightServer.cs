﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace TrimlightServer
{
    public class TrimlightServer
    {
        private static bool shouldDisconnect = false;

        static void Main()
        {
            string localIP = GetLocalIPAddress();
            Console.WriteLine($"Local IP Address: {localIP}");

            const int port = 5000;
            TcpListener server = new(IPAddress.Parse(localIP), port);

            try
            {
                server.Start();
                Console.WriteLine($"Server started on {localIP}:{port}");

                // Start a task to handle user input for `shouldDisconnect`
                Task.Run(() => MonitorConsoleInput());

                while (true)
                {
                    TcpClient client = server.AcceptTcpClient();
                    Console.WriteLine("Client connected.");

                    Task.Run(() => HandleClient(client));
                }
            }
            catch (Exception ex) 
            {
                Console.WriteLine($"Exception: {ex.Message}"); 
            }
            finally
            {
                server.Stop();
                Console.WriteLine("Server stopped.");
            }

        }

        static void HandleClient(TcpClient client)
        {
            try
            {
                NetworkStream stream = client.GetStream();

                // Read client request
                byte[] buffer = new byte[1024];
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                string request = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                Console.WriteLine($"Received: {request}");

                // Respond to the client
                string response = shouldDisconnect ? "Yes, disconnect" : "No, stay connected";
                byte[] responseBytes = Encoding.UTF8.GetBytes(response);
                stream.Write(responseBytes, 0, responseBytes.Length);
                Console.WriteLine($"Sent: {response}");

                // Close the connection
                client.Close();
                Console.WriteLine("Client disconnected.");
            }
            catch (Exception e)
            {
                Console.WriteLine($"Exception while handling client: {e.Message}");
            }
        }

        // Monitor console input to update `shouldDisconnect`
        static void MonitorConsoleInput()
        {
            while (true)
            {
                Console.WriteLine("Type 'yes' to enable disconnect or 'no' to disable disconnect:");
                string? input = Console.ReadLine()?.Trim().ToLower();

                if (input == "yes")
                {
                    shouldDisconnect = true;
                    Console.WriteLine("shouldDisconnect set to TRUE.");
                }
                else if (input == "no")
                {
                    shouldDisconnect = false;
                    Console.WriteLine("shouldDisconnect set to FALSE.");
                }
                else
                {
                    Console.WriteLine("Invalid input. Please type 'yes' or 'no'.");
                }
            }
        }

        static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("No IPv4 address found.");
        }
    }
}
