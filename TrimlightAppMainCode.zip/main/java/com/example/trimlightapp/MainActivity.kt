package com.example.trimlightapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.trimlightapp.ui.theme.TrimlightAppTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.PrintWriter
import java.net.Socket
import androidx.navigation.compose.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import java.net.HttpURLConnection
import java.net.URL
import okhttp3.*
import okio.ByteString

class WebSocketClient(private val serverUrl: String) {
    private val client = OkHttpClient()
    private var webSocket: WebSocket? = null

    fun connect() {
        val request = Request.Builder().url(serverUrl).build()
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                println("Connected to WebSocket!")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                println("Message received: $text")
                // Handle message from server
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                println("Binary message received: $bytes")
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                println("Closing WebSocket: $code / $reason")
                webSocket.close(1000, null)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                println("WebSocket Error: ${t.message}")
            }
        })
    }

    fun sendMessage(message: String) {
        webSocket?.send(message)
    }

    fun disconnect() {
        webSocket?.close(1000, "Client closed connection")
    }
}

class MainActivity : ComponentActivity() {
    private var webSocketClient: WebSocketClient? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TrimlightAppTheme {
                val navController = rememberNavController()
                var serverIpAddress by remember { mutableStateOf("") }
                var moduleIpAddress by remember { mutableStateOf("") }
                var isWebSocketConnected by remember { mutableStateOf(false) }

                // Establish WebSocket connection when IPs are set
                LaunchedEffect(serverIpAddress, moduleIpAddress) {
                    if (serverIpAddress.isNotEmpty() && moduleIpAddress.isNotEmpty() && !isWebSocketConnected) {
                        connectToWebSocket(serverIpAddress, moduleIpAddress)
                        isWebSocketConnected = true
                    }
                }

                NavHost(navController, startDestination = "connection_screen") {
                    composable("connection_screen") {
                        ConnectionScreen { enteredModuleIp ->
                            moduleIpAddress = enteredModuleIp
                            serverIpAddress = "ws://your_server_ip:your_port" // Replace with actual user input if needed
                            navController.navigate("main_screen?moduleIp=$enteredModuleIp")
                        }
                    }
                    composable("main_screen") {
                        MainScreen(serverIpAddress, moduleIpAddress)
                    }
                }
            }
        }
    }

    private fun connectToWebSocket(serverUrl: String, moduleIp: String) {
        webSocketClient = object : WebSocketClient(URI(serverUrl)) {
            override fun onOpen(handshakedata: ServerHandshake?) {
                println("WebSocket Connected!")
            }

            override fun onMessage(message: String?) {
                message?.let {
                    println("Received message: $it")
                    if (it == "TURN_ON" || it == "TURN_OFF") {
                        CoroutineScope(Dispatchers.IO).launch {
                            sendCommandToModule(moduleIp, it)
                        }
                    }
                }
            }

            override fun onClose(code: Int, reason: String?, remote: Boolean) {
                println("WebSocket Disconnected: $reason")
            }

            override fun onError(ex: Exception?) {
                println("WebSocket Error: ${ex?.message}")
            }
        }

        webSocketClient?.connect()
    }

    override fun onDestroy() {
        super.onDestroy()
        webSocketClient?.close()
    }
}

suspend fun connectToServer(ipAddress: String, message: String): String {
    return withContext(Dispatchers.IO) {
        try {
            val serverPort = 5000 // Replace with your server's port
            Socket(ipAddress, serverPort).use { socket ->
                val writer = PrintWriter(OutputStreamWriter(socket.getOutputStream()), true)
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))

                // Send a message to the server
                writer.println(message)

                // Read the server's response
                reader.readLine()
            }
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }
}

suspend fun connectToModule(moduleIpAddress: String): String {
    return withContext(Dispatchers.IO) {
        try {
            val url = URL("http://$moduleIpAddress/status") // Change "/status" to an endpoint your module provides
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            val responseCode = connection.responseCode
            if (responseCode == 200) {
                "Module connected successfully!"
            } else {
                "Error: Module responded with code $responseCode"
            }
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }
}


@Composable
fun ConnectionScreen(
    onNavigateToNextScreen: (String) -> Unit
) {
    var serverResponse by remember { mutableStateOf("Enter IP and press the button to connect to the server.") }
    var moduleResponse by remember { mutableStateOf("Enter IP and press the button to connect to the module.") }
    var ipAddress by remember { mutableStateOf("") }
    var moduleIpAddress by remember { mutableStateOf("") }
    var serverConnected by remember { mutableStateOf(false) }
    var moduleConnected by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(64.dp)
    ) {
        // Server Connection Section
        Text("Server Connection")
        TextField(
            value = ipAddress,
            onValueChange = { ipAddress = it },
            label = { Text("Server IP Address") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            serverResponse = "Connecting to server..."
            coroutineScope.launch {
                val response = connectToServer(ipAddress, "Hello Server!")
                serverResponse = response
                serverConnected = response.startsWith("Hello") // Assuming success response starts with "Hello"
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Connect to Server")
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(text = serverResponse)

        Spacer(modifier = Modifier.height(32.dp))

        // Wi-Fi Module Connection Section
        Text("Wi-Fi Module Connection")
        TextField(
            value = moduleIpAddress,
            onValueChange = { moduleIpAddress = it },
            label = { Text("Wi-Fi Module IP Address") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            moduleResponse = "Connecting to Wi-Fi module..."
            coroutineScope.launch {
                val response = connectToModule(moduleIpAddress)
                moduleResponse = response
                moduleConnected = response.startsWith("Module Connected successfully") // Assuming success response starts with "Hello"
            }
        }, Modifier.fillMaxWidth()) {
            Text("Connect to Wi-Fi Module")
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(text = moduleResponse)

        // Navigate Button (Enabled only if both are connected)
        if (serverConnected && moduleConnected) {
            Spacer(modifier = Modifier.height(32.dp))
            Button(onClick = {onNavigateToNextScreen(moduleIpAddress) }, modifier = Modifier.fillMaxWidth()) {
                Text("Proceed")
            }
        }

        // Proceed without connecting button
        Spacer(modifier = Modifier.height(128.dp))
        Button(onClick = { onNavigateToNextScreen(moduleIpAddress) }, modifier = Modifier.fillMaxWidth()) {
            Text("Proceed without connecting")
        }
    }
}

@Composable
fun MainScreen(serverIpAddress: String, moduleIpAddress: String) {
    val coroutineScope = rememberCoroutineScope()
    var responseText by remember { mutableStateOf("Toggle the lights.") }

    LaunchedEffect(serverIpAddress, moduleIpAddress) {
        startListeningForCommands(serverIpAddress, moduleIpAddress)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = responseText,
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Button(
            onClick = {
                coroutineScope.launch {
                    responseText = sendCommandToModule(moduleIpAddress, "TURN_ON")
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Turn On")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                coroutineScope.launch {
                    responseText = sendCommandToModule(moduleIpAddress, "TURN_OFF")
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Turn Off")
        }
    }
}

suspend fun sendCommandToModule(moduleIpAddress: String, command: String): String {
    return withContext(Dispatchers.IO) {
        try {
            val url = URL("http://$moduleIpAddress/${if (command == "TURN_ON") "H" else "L"}")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            val responseCode = connection.responseCode
            if (responseCode == 200) {
                "Command sent successfully!"
            } else {
                "Error: Server responded with code $responseCode"
            }
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }
}

fun startListeningForCommands(serverIp: String, moduleIpAddress: String) {
    CoroutineScope(Dispatchers.IO).launch {
        while (true) {
            try {
                val url = URL("http://$serverIp/get-command") // Endpoint for fetching command
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000

                val responseCode = connection.responseCode
                if (responseCode == 200) {
                    val command = connection.inputStream.bufferedReader().readText().trim()
                    if (command == "TOGGLE") {
                        toggleLights(moduleIpAddress)
                    }
                }
            } catch (e: Exception) {
                println("Error: ${e.message}")
            }

            delay(5000) // Poll every 5 seconds (adjust as needed)
        }
    }
}

suspend fun toggleLights(moduleIpAddress: String) {
    withContext(Dispatchers.IO) {
        try {
            val url = URL("http://$moduleIpAddress/TOGGLE")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            val responseCode = connection.responseCode
            println(if (responseCode == 200) "Toggled successfully!" else "Failed to toggle")
        } catch (e: Exception) {
            println("Error: ${e.message}")
        }
    }
}



@Preview(showBackground = true)
@Composable
fun ServerInteractionPreview() {
    TrimlightAppTheme {
        ConnectionScreen(
            onNavigateToNextScreen = {}
        )
    }
}
